<?php

/**
 * The file that defines the settings page
 *
 * Included in this file are all of the settings required to make the settings page
 * work in the wp-admin screens.
 *
 * @link       https://www.robertdevore.com
 * @since      1.0.0
 *
 * @package    TCWP
 * @subpackage TCWP/admin
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Configuration error message.
 *
 * @return void
 */
function show_config_error_message() {
    echo '<div id="tcwp-error" class="error fade"><p><strong>'.__( 'Twitter Comments for WordPress:' ).'</strong> '.sprintf(__( 'Please add your API Keys in the <a href="%s">plugin settings</a>.' ), 'admin.php?page=tcwp_settings' ) . '</p></div>';
}

// Add admin error notice if Twitter API keys are not added.
if ( ! tcwp_twitter_api_key() || ! tcwp_twitter_api_secret() || ! tcwp_twitter_access_token() || ! tcwp_twitter_access_secret() ) {
    add_action( 'admin_notices', 'show_config_error_message' );
}

/**
 * Define global constants.
 *
 * @since 1.0.0
 */
if ( ! defined( 'WPOSA_NAME' ) ) {
	define( 'WPOSA_NAME', trim( dirname( plugin_basename( __FILE__ ) ), '/' ) );
}
if ( ! defined( 'WPOSA_DIR' ) ) {
	define( 'WPOSA_DIR', WP_PLUGIN_DIR . '/' . WPOSA_NAME );
}
if ( ! defined( 'WPOSA_URL' ) ) {
	define( 'WPOSA_URL', WP_PLUGIN_URL . '/' . WPOSA_NAME );
}

/**
 * WP-OOP-Settings-API Initializer
 *
 * Initializes the WP-OOP-Settings-API.
 *
 * @since   1.0.0
 */

/**
 * Class `WP_OOP_Settings_API`.
 *
 * @since 1.0.0
 */
require_once WPOSA_DIR . '/class-tcwp-admin-settings.php';

/**
 * Actions/Filters
 *
 * Related to all settings API.
 *
 * @since  1.0.0
 */
if ( class_exists( 'WP_OSA' ) ) {
	/**
	 * Object Instantiation.
	 *
	 * Object for the class `WP_OSA`.
	 */
	$wposa_obj = new WP_OSA();
	// Section: Basic Settings.
	$wposa_obj->add_section(
		array(
			'id'    => 'wposa_basic',
			'title' => __( 'Basic Settings', 'tcwp' ),
		)
	);
	// Section: Other Settings.
	$wposa_obj->add_section(
		array(
			'id'    => 'wposa_advanced',
			'title' => __( 'Advanced Settings', 'tcwp' ),
		)
	);

	// Field: Title API Settings.
	$wposa_obj->add_field(
		'wposa_basic',
		array(
			'id'   => 'title_api_settings',
			'type' => 'title',
			'name' => '<h1>' . __( 'API Settings', 'tcwp' ) . '</h1>',
		)
	);
    // Field: Twitter API Key.
	$wposa_obj->add_field(
		'wposa_basic',
		array(
			'id'      => 'twitter_api_key',
			'type'    => 'text',
			'name'    => __( 'Twitter API Key', 'tcwp' ),
			'desc'    => __( 'Your Twitter Consumer Key (get keys by creating an app at dev.twitter.com/apps)', 'tcwp' ),
			'default' => '',
		)
	);
	// Field: Twitter API Secret Key.
	$wposa_obj->add_field(
		'wposa_basic',
		array(
			'id'      => 'twitter_api_secret',
			'type'    => 'text',
			'name'    => __( 'Twitter API Secret Key', 'tcwp' ),
			'desc'    => __( 'Your Twitter Consumer Secret.', 'tcwp' ),
			'default' => '',
		)
	);
    // Field: Twitter API Access Token.
	$wposa_obj->add_field(
		'wposa_basic',
		array(
			'id'      => 'twitter_access_token',
			'type'    => 'text',
			'name'    => __( 'Twitter API Access Token', 'tcwp' ),
			'desc'    => __( 'Your Twitter oAuth Access Token', 'tcwp' ),
			'default' => '',
		)
	);
	// Field: Twitter API Acess Token Secret.
	$wposa_obj->add_field(
		'wposa_basic',
		array(
			'id'      => 'twitter_access_secret',
			'type'    => 'text',
			'name'    => __( 'Twitter API Access Token Secret', 'tcwp' ),
			'desc'    => __( 'Your Twitter oAuth Access Token Secret.', 'tcwp' ),
			'default' => '',
		)
	);
	// Field: Title Posts.
	$wposa_obj->add_field(
		'wposa_basic',
		array(
			'id'   => 'title_post_settings',
			'type' => 'title',
			'name' => '<h1>' . __( 'Post Settings', 'tcwp' ) . '</h1>',
		)
	);
    // Field: Posts count.
	$wposa_obj->add_field(
		'wposa_basic',
		array(
			'id'                => 'posts_count',
			'type'              => 'number',
			'name'              => __( 'Number of posts to search for', 'tcwp' ),
			'desc'              => __( 'Choose how many blog posts to serch for.', 'tcwp' ),
			'default'           => 10,
			'sanitize_callback' => 'intval',
		)
    );
	// Field: Post search.
	$wposa_obj->add_field(
		'wposa_basic',
		array(
			'id'      => 'posts_search',
			'type'    => 'select',
			'name'    => __( 'Search posts by', 'tcwp' ),
			'desc'    => __( 'Choose how you would like TCWP to search your posts', 'tcwp' ),
			'options' => array(
				'most_recent'  => __( 'Most recent', 'tcwp' ),
				'most_popular' => __( 'Most popular', 'tcwp' ),
			),
		)
	);

    /*
    $args = array(
        'public'   => true,
        '_builtin' => true
    );
    
    $output = 'names'; // names or objects, note names is the default
    $operator = 'and'; // 'and' or 'or'
    
    $post_types = get_post_types( $args, $output, $operator );     

	// Field: Post types.
	$wposa_obj->add_field(
		'wposa_basic',
		array(
			'id'      => 'post_types',
			'type'    => 'multicheck',
			'name'    => __( 'Post types to search', 'tcwp' ),
            'desc'    => '',
			'options' => $post_types,
		)
    );
    */

    // Field: Tweets count.
	$wposa_obj->add_field(
		'wposa_advanced',
		array(
			'id'                => 'tweets_count',
			'type'              => 'number',
			'name'              => __( 'Number of tweets to search for', 'tcwp' ),
			'desc'              => __( 'Choose how many tweets each blog post will serch for.', 'tcwp' ),
			'default'           => 10,
			'sanitize_callback' => 'intval',
		)
    );

	// Field: Post search.
	$wposa_obj->add_field(
		'wposa_advanced',
		array(
			'id'      => 'comment_type',
			'type'    => 'select',
			'name'    => __( 'Comment type', 'tcwp' ),
			'desc'    => __( 'Most users will not need to change this setting, although you may prefer that Tweets appear as trackbacks or pingbacks if your theme displays these differently.', 'tcwp' ),
			'options' => array(
				''           => 'Comments (default)',
				'trackbacks' => 'Trackbacks',
                'pingbacks'  => 'Pingbacks',
			),
		)
	);
	// Field: Search frequency.
	$wposa_obj->add_field(
		'wposa_advanced',
		array(
			'id'      => 'search_frequency',
			'type'    => 'radio',
			'name'    => __( 'Search frequency', 'tcwp' ),
			'desc'    => __( 'How often would you like to search for new comments', 'tcwp' ),
			'options' => array(
				'hourly' => 'Hourly',
				'daily'  => 'Daily',
			),
		)
	);



    // Field: Password.
	$wposa_obj->add_field(
		'wposa_basic_NOTACTIVE',
		array(
			'id'   => 'password',
			'type' => 'password',
			'name' => __( 'Password Input', 'tcwp' ),
			'desc' => __( 'Password field description', 'tcwp' ),
		)
	);
	// Field: Textarea.
	$wposa_obj->add_field(
		'wposa_basic_NOTACTIVE',
		array(
			'id'   => 'textarea',
			'type' => 'textarea',
			'name' => __( 'Textarea Input', 'tcwp' ),
			'desc' => __( 'Textarea description', 'tcwp' ),
		)
	);
	// Field: Title.
	$wposa_obj->add_field(
		'wposa_basic_NOTACTIVE',
		array(
			'id'   => 'title',
			'type' => 'title',
			'name' => '<h1>' . __( 'Title', 'tcwp' ) . '</h1>',
		)
	);
	// Field: Checkbox.
	$wposa_obj->add_field(
		'wposa_basic_NOTACTIVE',
		array(
			'id'   => 'checkbox',
			'type' => 'checkbox',
			'name' => __( 'Checkbox', 'tcwp' ),
			'desc' => __( 'Checkbox Label', 'tcwp' ),
		)
	);
	// Field: Radio.
	$wposa_obj->add_field(
		'wposa_basic_NOTACTIVE',
		array(
			'id'      => 'radio',
			'type'    => 'radio',
			'name'    => __( 'Radio', 'tcwp' ),
			'desc'    => __( 'Radio Button', 'tcwp' ),
			'options' => array(
				'yes' => 'Yes',
				'no'  => 'No',
			),
		)
	);
	// Field: Multicheck.
	$wposa_obj->add_field(
		'wposa_basic_NOTACTIVE',
		array(
			'id'      => 'multicheck',
			'type'    => 'multicheck',
			'name'    => __( 'Multile checkbox', 'tcwp' ),
			'desc'    => __( 'Multile checkbox description', 'tcwp' ),
			'options' => array(
				'yes' => 'Yes',
				'no'  => 'No',
			),
		)
	);
	// Field: Select.
	$wposa_obj->add_field(
		'wposa_basic_NOTACTIVE',
		array(
			'id'      => 'select',
			'type'    => 'select',
			'name'    => __( 'A Dropdown', 'tcwp' ),
			'desc'    => __( 'A Dropdown description', 'tcwp' ),
			'options' => array(
				'yes' => 'Yes',
				'no'  => 'No',
			),
		)
	);

}
