<?php
/**
 * The file that defines all Metaboxes
 *
 * Included in this file are all of the settings required to search the Twitter API.
 *
 * @link       https://www.robertdevore.com
 * @since      1.0.0
 *
 * @package    TCWP
 * @subpackage TCWP/admin
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Skip Blog Post Tweet Search
 *
 * Adds checkbox to blog posts so users can skip the post in the Twitter Comments 
 * for WordPress searches.
 *
 * @since    1.0
 */
function tcwp_skip_post_meta( $value ) {
	global $post;

	$field = get_post_meta( $post->ID, $value, true );
	if ( ! empty( $field ) ) {
		return is_array( $field ) ? stripslashes_deep( $field ) : stripslashes( wp_kses_decode_entities( $field ) );
	} else {
		return false;
    }

}

function tcwp_skip_post_add_meta_box() {
	add_meta_box(
		'tcwp_skip_post',
		__( 'Twitter Comments for WP', 'tcwp' ),
		'tcwp_skip_post_html',
		apply_filters( 'tcwp_skip_post_metabox', array ( 'post' ) ),
		'side',
		'high'
	);
}
add_action( 'add_meta_boxes', 'tcwp_skip_post_add_meta_box' );

function tcwp_skip_post_html( $post ) {
	wp_nonce_field( '_tcwp_skip_post_nonce', 'tcwp_skip_post_nonce' ); ?>
	<p>
		<input type="checkbox" name="tcwp_skip_post" id="tcwp_skip_post" value="skip" <?php echo ( tcwp_skip_post_meta( 'tcwp_skip_post' ) === 'skip' ) ? 'checked' : 'no'; ?>>
		<label for="tcwp_skip_post"><?php _e( 'Don\'t save tweets as comments', 'tcwp' ); ?></label>
	</p>
	<?php
}

function tcwp_skip_post_save( $post_id ) {
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
	if ( ! isset( $_POST['tcwp_skip_post_nonce'] ) || ! wp_verify_nonce( $_POST['tcwp_skip_post_nonce'], '_tcwp_skip_post_nonce' ) ) return;
	if ( ! current_user_can( 'edit_post', $post_id ) ) return;

	if ( isset( $_POST['tcwp_skip_post'] ) )
		update_post_meta( $post_id, 'tcwp_skip_post', esc_attr( $_POST['tcwp_skip_post'] ) );
	else
		update_post_meta( $post_id, 'tcwp_skip_post', null );
}
add_action( 'save_post', 'tcwp_skip_post_save' );
