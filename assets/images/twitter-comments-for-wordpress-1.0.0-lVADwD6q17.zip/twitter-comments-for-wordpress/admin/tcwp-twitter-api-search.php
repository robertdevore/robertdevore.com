<?php
/**
 * The file that defines the Twitter API searches
 *
 * Included in this file are all of the settings required to search the Twitter API.
 *
 * @link       https://www.robertdevore.com
 * @since      1.0.0
 *
 * @package    TCWP
 * @subpackage TCWP/admin
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function tcwp_twitter_api_access() {

	/**
	 * Twitter API Settings.
	 */
	$settings = array(
		'oauth_access_token'        => tcwp_twitter_access_token(),
		'oauth_access_token_secret' => tcwp_twitter_access_secret(),
		'consumer_key'              => tcwp_twitter_api_key(),
		'consumer_secret'           => tcwp_twitter_api_secret()
	);

	$base_url      = 'https://api.twitter.com/1.1/search/tweets.json';
	$requestMethod = 'GET';

	// Order by.
	if ( 'most_popular' == tcwp_settings_posts_search() ) {
		$orderby = 'comment_count';
	} else {
		$orderby = 'date';
	}

	/**
	 * Posts args
	 */
	$args = array(
		'post_type'   => 'post',
		'post_status' => 'publish',
		'orderby'     => $orderby,
		'numberposts' => tcwp_settings_posts_count(),
		/*
		'meta_query' => array(
			array(
				'key'     => 'tcwp_skip_post',
				'value'   => 'skip',
				'compare' => '!='
			)
		)
		*/
	);

	// Get posts.
	$my_posts = get_posts( $args );

	//print_r( $my_posts );

	global $current_user;

	// Check for posts.
	if ( $my_posts ) {

		// Loop through each post.
		foreach ( $my_posts as $my_post ) {

			$url_encode = get_the_permalink( $my_post->ID );
			//$url_encode = 'https://www.webyantra.com/2019/01/16/startup-life-lessons-from-the-vinod-khosla-interview-how-to-build-the-future/';
			//$url_encode = 'https://techcrunch.com';
			$getfield   = '?q=' . $url_encode . '%20since%3A2015-01-01&count=' . tcwp_settings_tweets_count() . '&tweet_mode=extended&src=typd&vertical=default';

			// Create API Connection.
			$twitter = new TwitterAPIExchange( $settings );

			//echo 'Running twitter API search ... ';

			// Disconnect?
			if ( ! $twitter ) {
				return false;
			}

			// Save results.
			$results = $twitter->setGetfield( $getfield )
			->buildOauth( $base_url, $requestMethod )
			->performRequest();

			// Decode the JSON feed.
			$tweets = json_decode( $results );

			//echo 'Results found.';

			// Loop through results..
			foreach ( $tweets as $key ) {

				foreach ( $key as $key=>$value ) {

					/*
					echo '<pre>';
					print_r( $value );
					echo '</pre>';
					*/

					// Create new comment.
					if ( isset( $value->user ) ) {

						/*
						echo '<pre>';
						print_r( $value->user );
						echo '</pre>';
						*/

						//echo '<strong>USER CHECK WORKS</strong>';

						// Set the author URL.
						if ( isset( $value->user->entities->url ) ) {
							$author_url = $value->user->entities->url->urls[0]->expanded_url;
						} else {
							$author_url = '';
						}

						// Set comment data.
						$comment_data = array(
							'comment_author'       => $value->user->name,
							'comment_author_email' => 'tweet',
							'comment_author_url'   => $author_url,
							'comment_post_ID'      => $my_post->ID,
							'comment_content'      => $value->full_text . '<br /><br />via - <a href="https://twitter.com/statuses/'. $value->id_str .'" target="_blank">@' . $value->user->screen_name . '</a>',
							'comment_type'         => tcwp_settings_comment_type(), // empty for regular comments, 'pingback' for pingbacks, 'trackback' for trackbacks
							'comment_parent'       => 0, // 0 if it's not a reply to another comment; if it's a reply, mention the parent comment ID here
						);

						// Check if comment exists.
						$args = array(
							'meta_key'   => 'tcwp_comment_tweet_id',
							'meta_value' => $value->id_str
						);

						// perform the query
						$comment_query = get_comments( $args );

						// Get comments array.
						$comment_ids = $comment_query;

						// Add Comment.
						if ( empty( $comment_ids ) ) {

							// Insert comment and get ID.
							$comment_id = wp_new_comment( $comment_data );

							// Update comment status.
							wp_set_comment_status( $comment_id, 'hold' );

							// Update comment metadata.
							add_comment_meta( $comment_id, 'tcwp_comment_tweet_id', $value->id_str, TRUE );
							add_comment_meta( $comment_id, 'tcwp_comment_twitter_username', $value->user->screen_name, TRUE );
							add_comment_meta( $comment_id, 'tcwp_comment_twitter_avatar', $value->user->profile_image_url_https, TRUE );

						}
					} // create new comment.
					update_option( 'tcwp_twitter_api_connect', '1' );
				}
			} // foreach $tweets as $key 
		} // foreach $my_posts as $my_post
	} // $my_post
}
add_action( 'init', 'tcwp_twitter_api_access' );

// Schedule the Twitter API Search if it's not already scheduled.
if ( ! wp_next_scheduled( 'tcwp_search_twitter_comments' ) ) {
	wp_schedule_event( strtotime( '+1 day', time() ), tcwp_settings_search_frequency(), 'tcwp_search_twitter_comments' );
}

// Hook into that action that'll run the scheduled event above.
add_action( 'tcwp_search_twitter_comments', 'tcwp_reset_database_connect' );

// Reset database connection for cron job.
function tcwp_reset_database_connect() {
	delete_option( 'tcwp_twitter_api_connect' );
}

/**
 * Twitter Profile Pictures as Gravatar
 * 
 * Use the Twitter profile image from the meta_data as 
 * gravatar replacement
 * 
 * @return string
 */
function tcwp_twitter_profile_avatar_url( $url, $id_or_email, $args ) {

	$user = '';

	// Get user by id or email.
    if ( is_numeric( $id_or_email ) ) {

		$id   = (int) $id_or_email;
        $user = get_user_by( 'id', $id );

	} elseif ( is_object( $id_or_email ) ) {

        if ( ! empty( $id_or_email->user_id ) ) {
            $id   = (int) $id_or_email->user_id;
            $user = get_user_by( 'id', $id );
		}

        if ( ! empty( $id_or_email->comment_ID ) ) {
			// Get Twitter profile image URL saved to comment.
			$twitter_avatar = get_comment_meta( $id_or_email->comment_ID, 'tcwp_comment_twitter_avatar', TRUE );

			// Change avatar image.
			if ( $twitter_avatar ) {
				return $twitter_avatar;
			}
		}

    } else {
        $user = get_user_by( 'email', $id_or_email );
	}

    return $url;
}
add_filter( 'get_avatar_url', 'tcwp_twitter_profile_avatar_url', 10, 5 );

//$api_connect = get_option( 'tcwp_twitter_api_connect' );

//var_dump( $api_connect );

//echo '<strong>$api_connect:</strong> ' . $api_connect;
