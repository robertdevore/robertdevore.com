<?php

/**
 * Fired during plugin activation
 *
 * @link       https://www.robertdevore.com
 * @since      1.0.0
 *
 * @package    TCWP
 * @subpackage TCWP/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    TCWP
 * @subpackage TCWP/includes
 * @author     Robert DeVore <deviodigital@gmail.com>
 */
class TCWP_Activator {

	/**
	 * Run on activataion
	 *
	 * Add functions and other codes here to run when the plugin is activated.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}

/**
 * Custom database options
 * 
 * @since 1.0
 */
function tcwp_add_default_options() {
	// Add default post search type.
	add_option( 'posts_search', 'most_recent' );
}
register_activation_hook( __FILE__, 'tcwp_add_default_options' );
