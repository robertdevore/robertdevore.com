<?php

/**
 * Get the Twitter API Key.
 *
 * @return string
 */
function tcwp_twitter_api_key() {
    $basic   = get_option( 'wposa_basic' );

    if ( isset( $basic['twitter_api_key'] ) && '' !== $basic['twitter_api_key'] ) {
        $api_key = $basic['twitter_api_key'];
    } else {
        $api_key = FALSE;
    }

	return apply_filters( 'tcwp_twitter_api_key', $api_key );
}

/**
 * Get the Twitter API Secret.
 *
 * @return string
 */
function tcwp_twitter_api_secret() {
    $basic      = get_option( 'wposa_basic' );

    if ( isset( $basic['twitter_api_secret'] ) && '' !== $basic['twitter_api_secret'] ) {
        $api_secret = $basic['twitter_api_secret'];
    } else {
        $api_secret = FALSE;
    }

	return apply_filters( 'tcwp_twitter_api_secret', $api_secret );
}

/**
 * Get the Twitter API Key Access Token.
 *
 * @return string
 */
function tcwp_twitter_access_token() {
    $basic = get_option( 'wposa_basic' );

    if ( isset( $basic['twitter_access_token'] ) && '' !== $basic['twitter_access_token'] ) {
        $access_token = $basic['twitter_access_token'];
    } else {
        $access_token = FALSE;
    }

	return apply_filters( 'tcwp_twitter_access_token', $access_token );
}

/**
 * Get the Twitter API Access Token Secret.
 *
 * @return string
 */
function tcwp_twitter_access_secret() {
    $basic = get_option( 'wposa_basic' );

    if ( isset( $basic['twitter_access_secret'] ) && '' !== $basic['twitter_access_secret'] ) {
        $access_secret = $basic['twitter_access_secret'];
    } else {
        $access_secret = FALSE;
    }

	return apply_filters( 'tcwp_twitter_access_secret', $access_secret );
}

/**
 * Get the Posts Count.
 *
 * @return string
 */
function tcwp_settings_posts_count() {
    $basic = get_option( 'wposa_basic' );

    if ( isset( $basic['posts_count'] ) ) {
        $posts_count = $basic['posts_count'];
    } else {
        $posts_count = 10;
    }

	return apply_filters( 'tcwp_settings_posts_count', $posts_count );
}

/**
 * Get the Posts Search.
 *
 * @return string
 */
function tcwp_settings_posts_search() {
    $basic = get_option( 'wposa_basic' );

    if ( isset( $basic['posts_search'] ) ) {
        $posts_search = $basic['posts_search'];
    } else {
        $posts_search = FALSE;
    }

	return apply_filters( 'tcwp_settings_posts_search', $posts_search );
}

/**
 * Get the Tweet Count.
 *
 * @return string
 */
function tcwp_settings_tweets_count() {
    $basic = get_option( 'wposa_basic' );

    if ( isset( $basic['tweets_count'] ) ) {
        $tweets_count = $basic['tweets_count'];
    } else {
        $tweets_count = 10;
    }

	return apply_filters( 'tcwp_settings_tweets_count', $tweets_count );
}

/**
 * Get the Comment type.
 *
 * @return string
 */
function tcwp_settings_comment_type() {
    $advanced = get_option( 'wposa_advanced' );

    if ( isset( $advanced['comment_type'] ) ) {
        $comment_type = $advanced['comment_type'];
    } else {
        $comment_type = '';
    }

	return apply_filters( 'tcwp_settings_comment_type', $comment_type );
}

/**
 * Get the Comment type.
 *
 * @return string
 */
function tcwp_settings_search_frequency() {
    $advanced = get_option( 'wposa_advanced' );

    if ( isset( $advanced['search_frequency'] ) ) {
        $search_frequency = $advanced['search_frequency'];
    } else {
        $search_frequency = 'daily';
    }

	return apply_filters( 'tcwp_settings_search_frequency', $search_frequency );
}
