<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://www.robertdevore.com
 * @since             1.0.0
 * @package           TCWP
 *
 * @wordpress-plugin
 * Plugin Name:       Twitter Comments for WordPress
 * Plugin URI:        http://www.webyantra.com/
 * Description:       Connect to the Twitter API, search for tweets mentioning your blog posts and import them as comments.
 * Version:           1.0.0
 * Author:            Robert DeVore
 * Author URI:        https://www.robertdevore.com
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       tcwp
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'TCWP_VERSION', '1.0.0' );

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-tcwp-activator.php
 */
function activate_tcwp() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-tcwp-activator.php';
	TCWP_Activator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-tcwp-deactivator.php
 */
function deactivate_tcwp() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-tcwp-deactivator.php';
	TCWP_Deactivator::deactivate();
}

register_activation_hook( __FILE__, 'activate_tcwp' );
register_deactivation_hook( __FILE__, 'deactivate_tcwp' );

/**
 * The core plugin class that is used to define internationalization,
 * admin-specific hooks, and public-facing site hooks.
 */
require plugin_dir_path( __FILE__ ) . 'includes/class-tcwp.php';

/**
 * Begins execution of the plugin.
 *
 * Since everything within the plugin is registered via hooks,
 * then kicking off the plugin from this point in the file does
 * not affect the page life cycle.
 *
 * @since    1.0.0
 */
function run_tcwp() {

	$plugin = new TCWP();
	$plugin->run();

}
run_tcwp();

/**
 * Add a check for our plugin before redirecting
 */
function tcwp_activate() {
    add_option( 'tcwp_do_activation_redirect', true );
}
register_activation_hook( __FILE__, 'tcwp_activate' );

/**
 * Add settings link on plugin page
 *
 * @since 1.0.3
 * @param array $links an array of links related to the plugin.
 * @return array updatead array of links related to the plugin.
 */
function tcwp_settings_link( $links ) {
	$settings_link = '<a href="admin.php?page=tcwp_settings">' . __( 'Settings', 'tcwp' ) . '</a>';
	array_unshift( $links, $settings_link );
	return $links;
}

$pluginname = plugin_basename( __FILE__ );

add_filter( "plugin_action_links_$pluginname", 'tcwp_settings_link' );

//echo '<strong>Echo: ' . get_option( 'tcwp_twitter_api_connect' ) . '</strong> - Var Dump: ';
//var_dump( get_option( 'tcwp_twitter_api_connect' ) );

/**
 * Redirect to the Dispensary Blocks Getting Started page on single plugin activation
 */
function tcwp_redirect() {
    if ( get_option( 'tcwp_do_activation_redirect', false ) ) {
        delete_option( 'tcwp_do_activation_redirect' );
        if ( ! isset( $_GET['activate-multi'] ) ) {
            wp_redirect( "admin.php?page=tcwp_settings" );
        }
    }
}
add_action( 'admin_init', 'tcwp_redirect' );
