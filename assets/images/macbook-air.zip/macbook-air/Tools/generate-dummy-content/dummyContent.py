#!/usr/bin/env python3

import os
import sys
import random
import string
from datetime import datetime, timedelta

# A small list of words to pick from for random text
WORD_POOL = [
    "lorem", "ipsum", "dolor", "sit", "amet", "consectetur", "adipiscing", 
    "elit", "sed", "do", "eiusmod", "tempor", "incididunt", "ut", "labore", 
    "et", "dolore", "magna", "aliqua", "volutpat", "bibendum", "arcu", 
    "vitae", "elementum", "curabitur", "quis", "tortor", "sapien", "varius", 
    "quam", "pharetra", "luctus"
]

def random_date(start_year=2019, end_year=2025):
    """
    Generate a random date between (start_year-01-01) and (end_year-12-31).
    Returns a date string in YYYY-MM-DD format.
    """
    start = datetime(start_year, 1, 1)
    end = datetime(end_year, 12, 31)
    
    # Get a random day delta between the start and end range
    random_day = random.randint(0, (end - start).days)
    date_obj = start + timedelta(days=random_day)
    return date_obj.strftime("%Y-%m-%d")

def random_words(min_words=2, max_words=5):
    """
    Return a string of random words from WORD_POOL,
    length between min_words and max_words (inclusive).
    """
    num_words = random.randint(min_words, max_words)
    return " ".join(random.choice(WORD_POOL) for _ in range(num_words))

def random_title():
    """
    Generate a random title (2-6 words, capitalized).
    """
    title_words = random_words(2, 6).split()
    # Capitalize each word for a title-like look
    return " ".join(word.capitalize() for word in title_words)

def random_custom_url():
    """
    Generate a random custom URL slug (3-7 words, joined by dashes).
    """
    slug_words = random_words(3, 7).split()
    return "-".join(slug_words)

def random_author():
    """Return a random author ID between 1 and 10."""
    return str(random.randint(1, 10))

def random_categories():
    """
    Return a list of 1-3 random category IDs (as integers between 1 and 10).
    Example: [2, 7, 9].
    """
    num_categories = random.randint(1, 3)
    categories = random.sample(range(1, 11), num_categories)
    return categories

def random_paragraph(sentence_count=3):
    """
    Generate a paragraph with a given number of sentences, each 6-12 words long.
    """
    sentences = []
    for _ in range(sentence_count):
        length = random.randint(6, 12)
        sentence_words = [random.choice(WORD_POOL) for _ in range(length)]
        # Capitalize first word and add a period
        sentence = sentence_words[0].capitalize() + " " + " ".join(sentence_words[1:]) + "."
        sentences.append(sentence)
    return " ".join(sentences)

def random_body(paragraph_count=3):
    """
    Create random Markdown-like body text with multiple paragraphs.
    """
    paragraphs = []
    for _ in range(paragraph_count):
        paragraphs.append(random_paragraph(sentence_count=random.randint(2, 5)))
    return "\n\n".join(paragraphs)

def generate_dummy_markdown_files(num_files, output_dir="dummy_content"):
    # Ensure the output directory exists
    os.makedirs(output_dir, exist_ok=True)
    
    for i in range(num_files):
        # Randomize all front matter
        title = random_title()
        custom_url = random_custom_url()
        author_id = random_author()
        date_str = random_date(2019, 2025)
        cats = random_categories()
        
        # Convert categories list to the YAML array style
        categories_yaml = "\n".join([f"  - {c}" for c in cats])
        
        # Create a random body with multiple paragraphs
        body_content = random_body(paragraph_count=random.randint(2, 5))
        
        # Build the final content
        file_content = f"""---
title: {title}
custom_url: {custom_url}
author: {author_id}
date: {date_str}
categories:
{categories_yaml}
---

{body_content}
"""
        # Use the custom URL to name the file (plus index to avoid collisions)
        filename = f"{custom_url}-{i+1}.md"
        filepath = os.path.join(output_dir, filename)
        
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(file_content)
        
        print(f"Created {filepath}")

def main():
    # Default number of files to generate
    num_files = 5
    
    # If the user gave a number on the command line, parse it
    if len(sys.argv) > 1:
        try:
            num_files = int(sys.argv[1])
        except ValueError:
            print("Usage: python generate_random_dummy_data.py <number_of_files>")
            sys.exit(1)
    
    output_dir = "dummy_content"
    
    generate_dummy_markdown_files(num_files, output_dir)
    print(f"\nSuccessfully generated {num_files} Markdown files in '{output_dir}'.")

if __name__ == "__main__":
    main()
