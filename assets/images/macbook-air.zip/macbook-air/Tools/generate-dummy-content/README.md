# Generate Dummy Content

## Overview
This is a Python script designed to generate and manipulate dummy content for various purposes such as testing, development, and demonstration with [Stattic](https://stattic.site).

## Features
- Generate random text content
- Create placeholder data for testing
- Easily customizable to fit specific needs

## Requirements
- Python 3.x

## Installation
To use `dummyContent.py`, simply clone the repository and navigate to the directory containing the script.

## Usage
To generate dummy Markdown files, run the script with the desired number of files as an argument:
```sh
python3 dummyContent.py <number_of_files>
```
If no number is provided, the script will default to generating 5 files.
