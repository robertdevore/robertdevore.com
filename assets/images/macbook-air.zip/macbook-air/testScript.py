import os
import csv
from os.path import getsize
import sys

def scan_folder(input_folder, output_file):
    # List to store the results
    results = []

    # Walk through all files in the input folder and its subfolders
    for root, dirs, files in os.walk(input_folder):
        for file in files:
            # Get the full path of the file
            file_path = os.path.join(root, file)

            # Get the size of the file in bytes
            file_size = getsize(file_path)

            # Check if the file is larger than 1MB (1024 KB)
            if file_size > 1024 * 1024:
                results.append([file_path, file_size])

    # Save the results to a CSV file
    try:
        with open(output_file, 'w', newline='', encoding='utf-8') as csvfile:
            writer = csv.writer(csvfile)
            writer.writerow(["File Path", "Size (bytes)"])

            for entry in results:
                writer.writerow(entry)

        print(f"Results saved to {output_file}")
    except Exception as e:
        print(f"An error occurred: {str(e)}")

# Usage example with command line argument
input_folder = sys.argv[1]
output_file = "results.csv"

scan_folder(input_folder, output_file)