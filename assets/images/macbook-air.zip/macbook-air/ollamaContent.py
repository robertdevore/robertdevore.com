import os
import argparse
from ollama import Ollama, AutoModel

def initialize_ollama_client():
    """Initialize Ollama's local server with DeepSeek R1 7B model."""
    return Ollama(
        "http://localhost:11434",
        model="deepseek-R1-7B-instruct-v1.0",
        temperature=0.7,
        max_tokens=2000
    )

def main():
    parser = argparse.ArgumentParser(description='Use Ollama with DeepSeek R1 7B to generate markdown content.')
    parser.add_argument('prompt', type=str, help='The input text to generate from')
    args = parser.parse_args()
    
    print("\nWelcome! This script will use Ollama's local server ( running locally )")
    print("to generate markdown content based on your input.")
    
    # Initialize the Ollama client once outside the loop
    client = initialize_ollama_client()
    
    try:
        generated_text = client.generate(
            prompt=args.prompt,
            stream=False,
            temperature=0.7,
            max_tokens=2000
        )
        print("\nGenerated content:")
        print(generated_text)
        
        # Write both the input and output to a markdown file
        with open('markdown_output.md', 'w') as f:
            f.write(f"### Input Text:\n\n{args.prompt}\n\n")
            f.write(f"### Generated Content:\n\n{generated_text}")
            
        print("\nMarkdown content has been saved to markdown_output.md.")
        
    except Exception as e:
        print(f"\nError occurred during generation: {str(e)}")
        print("The script will exit gracefully.")

if __name__ == "__main__":
    main()
